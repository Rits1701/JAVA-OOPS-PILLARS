╔══════════════════════════════════════════════════════════════╗
║       JAVA TECH LEAD INTERVIEW PREP — EU EDITION            ║
║       3-Week Study Bundle · France / Netherlands / Germany  ║
╚══════════════════════════════════════════════════════════════╝

FILES IN THIS BUNDLE
────────────────────

1. java_techlead_prep.html
   • 21-day roadmap with checkboxes (progress saved in browser)
   • 30+ Q&A flashcards (Core Java, Spring, Microservices, System Design)
   • EU interview patterns: Booking.com, Adyen, Zalando, Doctolib, etc.
   • Daily reminder setup

2. hexagonal_architecture.html
   • Interactive diagram — click adapters to jump to code
   • Full Java code: Domain, Input Port, Output Port, Adapters, Unit Tests
   • Interview Q&A with EU company context (Zalando, Adyen, BlaBlaCar)

3. oop_pillars.html
   • All 4 OOP pillars: Encapsulation, Inheritance, Polymorphism, Abstraction
   • Violation vs Correct code examples for each
   • One-liners to memorise · Interview Q&A for each pillar

HOW TO USE
──────────
Open each file in any modern browser (Chrome, Firefox, Edge, Safari).
No internet connection required. No server needed.
Just double-click the .html file.

STUDY ORDER (recommended)
──────────────────────────
Week 1, Day 1  → oop_pillars.html
Week 1, Day 6+ → hexagonal_architecture.html
All 3 weeks    → java_techlead_prep.html (roadmap tracker)

Good luck! 🚀 ☕
